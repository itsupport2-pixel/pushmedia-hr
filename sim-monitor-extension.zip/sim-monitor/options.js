/* หน้าตั้งค่าของส่วนขยาย SIM Monitor · เก็บคีย์ใน chrome.storage.local ของเครื่องนี้เท่านั้น */
const DEF = { api: 'https://pushmedia-hr-api.itsupport2-3a4.workers.dev', hr: 'https://pct.push.co.th/admin.html', key: '', on: true, hour: 7 };
const $ = id => document.getElementById(id);
const fdt = t => t ? new Date(t).toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const KIND = { auto: 'ซิงก์สถานะ', quick: 'Sync เร็ว', full: 'Sync เต็ม', hist: 'ดึงประวัติ' };
async function load() {
  const c = Object.assign({}, DEF, (await chrome.storage.local.get('cfg')).cfg || {}), s = (await chrome.storage.local.get('st')).st || {};
  $('key').value = c.key; $('hour').value = c.hour; $('on').checked = !!c.on; $('api').value = c.api; $('hr').value = c.hr;
  const L = s.last;
  $('st').innerHTML = (!c.key ? '<b class="bad">ยังไม่ได้ใส่คีย์</b>' : s.busyAt ? '<b>กำลังซิงก์…</b>' : L ? '<b class="' + (L.state === 'done' ? 'ok' : 'bad') + '">' + (L.state === 'done' ? 'สำเร็จ' : L.state === 'login' ? 'ต้องเข้าสู่ระบบ CMP' : 'ไม่สำเร็จ') + ' · ' + (KIND[L.kind] || L.kind) + '</b>' + (L.msg ? L.msg.replace(/</g, '&lt;') + '<br>' : '') + '<span class="faint">' + fdt(L.at) + '</span>' : '<b>ยังไม่เคยซิงก์</b>') +
    '<div class="faint" style="margin-top:6px">ซิงก์สถานะล่าสุด: ' + (s.quick || '—') + ' · ประวัติล่าสุด: ' + fdt(s.histAt) + '</div>';
}
$('save').onclick = async () => {
  const k = $('key').value.trim();
  if (k && !/^sk_[0-9a-f]{32}$/.test(k)) { alert('คีย์ไม่ถูกต้อง · คัดลอกจากหน้า HR › SIM Monitor › ซิงก์ข้อมูล'); return; }
  const h = Math.max(0, Math.min(23, Math.round(Number($('hour').value) || 0)));
  await chrome.storage.local.set({ cfg: { key: k, hour: h, on: $('on').checked, api: $('api').value.trim() || DEF.api, hr: $('hr').value.trim() || DEF.hr } });
  load(); $('save').textContent = 'บันทึกแล้ว'; setTimeout(() => { $('save').textContent = 'บันทึก'; }, 1500);
};
const run = kind => async () => { $('st').innerHTML = '<b>กำลังซิงก์…</b><span class="faint">เปิดแท็บ CMP เบื้องหลัง · ปิดหน้าต่างนี้ได้</span>'; await chrome.runtime.sendMessage({ run: kind }); load(); };
$('runq').onclick = run('auto'); $('runh').onclick = run('hist');
load(); setInterval(load, 4000);
