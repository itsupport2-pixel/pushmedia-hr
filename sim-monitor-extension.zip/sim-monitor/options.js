/* หน้าต่างส่วนขยาย SIM Monitor · เก็บคีย์ใน chrome.storage.local ของเครื่องนี้เท่านั้น · แสดงความคืบหน้าระหว่างซิงก์ */
const DEF = { api: 'https://pushmedia-hr-api.itsupport2-3a4.workers.dev', hr: 'https://pct.push.co.th/admin.html', key: '', on: true, hour: 7 };
const $ = id => document.getElementById(id);
const fdt = t => t ? new Date(t).toLocaleString('th-TH', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const KIND = { auto: 'ซิงก์สถานะ', quick: 'Sync เร็ว', full: 'Sync เต็ม', hist: 'ดึงประวัติรายเดือน' };
const TMF = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'], mth = m => TMF[+m.slice(5, 7) - 1] + ' ' + (+m.slice(0, 4) + 543);
const thMon = (n = 0) => { const d = new Date(Date.now() + 7 * 3600e3); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() + n); return d.toISOString().slice(0, 7); };
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let first = true;
async function load() {
  const c = Object.assign({}, DEF, (await chrome.storage.local.get('cfg')).cfg || {}), s = (await chrome.storage.local.get('st')).st || {};
  if (first) { $('key').value = c.key; $('hour').value = c.hour; $('on').checked = !!c.on; $('api').value = c.api; $('hr').value = c.hr; $('ver').textContent = 'รุ่น ' + chrome.runtime.getManifest().version; if (!c.key) $('dset').open = true; $('hf').value = $('hf').value || thMon(-1); $('ht').value = $('ht').value || thMon(-1); $('hf').max = $('ht').max = thMon(0); first = false; }
  const busy = s.busyAt && Date.now() - s.busyAt < 70 * 60e3, L = s.last, el = $('st');
  $('runq').disabled = $('runf').disabled = $('runh').disabled = !!busy || !c.key;
  if (!c.key) { el.className = 'st bad'; el.innerHTML = '<b>ยังไม่ได้ใส่คีย์</b>เปิด "ตั้งค่า" ด้านล่าง แล้ววางคีย์จากหน้า HR › SIM Monitor › ซิงก์ข้อมูล'; return; }
  if (busy) { el.className = 'st run'; const pm = (s.prog || {}).mon; el.innerHTML = '<b>กำลัง' + esc(KIND[(s.prog || {}).kind] || 'ซิงก์') + (pm ? ' ' + esc(mth(pm.from) + (pm.to !== pm.from ? ' – ' + mth(pm.to) : '')) : '') + '…</b>' + esc((s.prog || {}).msg || '') + '<div class="bar"><i></i></div><div class="faint" style="margin-top:6px">ปิดหน้าต่างนี้ได้ · ระบบทำงานต่อเบื้องหลัง</div>'; return; }
  const ok = L && L.state === 'done';
  el.className = 'st ' + (!L ? '' : ok ? 'ok' : 'bad');
  el.innerHTML = (L ? '<b>' + (ok ? 'สำเร็จ' : L.state === 'login' ? 'ต้องเข้าสู่ระบบ CMP' : 'ไม่สำเร็จ') + ' · ' + esc(KIND[L.kind] || L.kind) + '</b>' + (L.msg ? esc(L.msg) + '<br>' : '') + '<span class="faint">' + fdt(L.at) + '</span>' : '<b>ยังไม่เคยซิงก์</b>') +
    '<div class="faint" style="margin-top:6px">ซิงก์สถานะล่าสุด: ' + (s.quick || '—') + '</div>';
}
$('save').onclick = async () => {
  const k = $('key').value.trim();
  if (k && !/^sk_[0-9a-f]{32}$/.test(k)) { alert('คีย์ไม่ถูกต้อง · คัดลอกจากหน้า HR › SIM Monitor › ซิงก์ข้อมูล'); return; }
  const h = Math.max(0, Math.min(23, Math.round(Number($('hour').value) || 0)));
  await chrome.storage.local.set({ cfg: { key: k, hour: h, on: $('on').checked, api: $('api').value.trim() || DEF.api, hr: $('hr').value.trim() || DEF.hr } });
  $('save').textContent = 'บันทึกแล้ว'; setTimeout(() => { $('save').textContent = 'บันทึก'; }, 1500); load();
};
const run = kind => () => { chrome.runtime.sendMessage({ run: kind }); setTimeout(load, 400); };
$('runq').onclick = run('auto');
$('runf').onclick = () => { if (confirm('Sync เต็มตอนนี้? ใช้เวลาประมาณ 10 นาที · ระหว่างนั้นจะมีหน้าต่าง CMP ย่ออยู่ใน Dock (ไม่ต้องปิด)')) run('full')(); };
$('runh').onclick = () => {
  let f = $('hf').value, t = $('ht').value || f; if (!f) { alert('เลือกเดือนที่จะดึงก่อน'); return; } if (t < f) [f, t] = [t, f];
  const n = (+t.slice(0, 4) - +f.slice(0, 4)) * 12 + (+t.slice(5) - +f.slice(5)) + 1;
  if (!confirm('ดึงประวัติ ' + mth(f) + (t !== f ? ' – ' + mth(t) : '') + ' (' + n + ' เดือน)?\n\nไล่ดึงทีละครึ่งเดือน · อาจใช้เวลานาน (หลายนาทีต่อครึ่งเดือน)\nระหว่างดึง บัญชี CMP นี้จะค้างทั้งบัญชี · มีหน้าต่าง CMP ย่ออยู่ใน Dock (ไม่ต้องปิด)')) return;
  chrome.runtime.sendMessage({ run: 'hist', mon: { from: f, to: t, force: $('hforce').checked } }); setTimeout(load, 400);
};
load(); setInterval(load, 1500);
