/* ส่วนขยาย Chrome "SIM Monitor" (24 พ.ย. 2569 · ผู้ใช้เลือกแบบ ก.) · ซิงก์ CMP → ระบบ HR อัตโนมัติ
 * ไม่เก็บรหัส dtac · ใช้การเข้าสู่ระบบ CMP ของเบราว์เซอร์นี้ (ติ๊ก "ให้ฉันลงชื่อเข้าใช้เสมอ") · CMP มี captcha → หลุดจากระบบ = แจ้งเตือนให้คนเข้าใหม่
 * ทุก 30 นาที (ตั้งแต่ 07:00 เวลาไทย): ยังไม่ซิงก์วันนี้ → เปิด /msisdn → simBmMain(..., 'auto') (Sync เต็มเมื่อระบบ HR บอกว่าถึงรอบ)
 *   ประวัติเกิน 7 วัน → เปิด /report → ดึงช่วงครึ่งเดือนที่ขาด · เสร็จแล้วปิดเอง
 * 1.2.0 (24 พ.ย. 2569 ผู้ใช้: "กดดึงข้อมูลตอนนี้แล้วไม่เคยผ่าน · No tab with id"):
 *   - เปิด CMP ในหน้าต่างแยกที่ย่อไว้ (ไม่ใช่แท็บในหน้าต่างที่ใช้งาน · ไม่ถูกปิดโดยไม่ตั้งใจ) + autoDiscardable:false (Memory Saver ไม่พักแท็บ)
 *   - tabs.onReplaced → ตามแท็บใหม่ · แท็บหายกลางทาง = ช่วงที่ส่งแล้วบันทึกไว้ รอบถัดไปดึงต่อ
 *   - ความคืบหน้า (window.__PMHR_PROG) เก็บใน storage → หน้าต่างส่วนขยายแสดง
 *   - โค้ดซิงก์: ใช้ sim-bm.js ในส่วนขยาย แล้วลองโหลดรุ่นล่าสุดจากหน้าเว็บ HR ทับ (แก้วิธีดึงข้อมูลได้โดยไม่ต้องติดตั้งส่วนขยายใหม่)
 *   - กดซ้ำระหว่างทำงาน = แจ้งว่ากำลังซิงก์อยู่
 * 1.3.0: เลิกเปิดหน้ารายงานอัตโนมัติ · ระบบ HR นับความเคลื่อนไหวรายวันจากการซิงก์สถานะทุกเช้าเอง
 * 1.4.0 (24 พ.ย. 2569 ผู้ใช้ขอ): ปุ่ม Sync เต็มตอนนี้ (run 'full' → simBmMain AUTO 'full') */
const CMP = 'https://cmp.dtac.co.th';
const DEF = { api: 'https://pushmedia-hr-api.itsupport2-3a4.workers.dev', hr: 'https://pct.push.co.th/admin.html', key: '', on: true, hour: 7 };
const thDate = () => new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
const thHour = () => new Date(Date.now() + 7 * 3600e3).getUTCHours();
const cfg = async () => Object.assign({}, DEF, (await chrome.storage.local.get('cfg')).cfg || {});
const st = async () => (await chrome.storage.local.get('st')).st || {};
const setSt = async p => { const s = Object.assign(await st(), p); await chrome.storage.local.set({ st: s }); return s; };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const TH = m => /No tab with id|tab was closed|No window with id/i.test(m) ? 'หน้า CMP ถูกปิดระหว่างดึงข้อมูล · ช่วงที่ส่งแล้วบันทึกไว้ · รอบถัดไปดึงต่อเอง (หรือกดอีกครั้ง)' : /Frame with ID|was removed|navigat/i.test(m) ? 'หน้า CMP เปลี่ยนหน้าระหว่างดึงข้อมูล · กดอีกครั้ง' : m;

const arm = () => chrome.alarms.create('tick', { periodInMinutes: 30, delayInMinutes: 1 });
chrome.runtime.onInstalled.addListener(arm);
chrome.runtime.onStartup.addListener(() => { arm(); tick(); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'tick') tick(); });
chrome.runtime.onMessage.addListener((m, s, reply) => { if (m && m.run) { runNow(m.run, true).then(reply); return true; } });
let CUR = null;   // แท็บที่กำลังใช้ (เปลี่ยนเมื่อ Chrome สลับแท็บ)
if (chrome.tabs.onReplaced) chrome.tabs.onReplaced.addListener((added, removed) => { if (CUR && CUR.tab === removed) CUR.tab = added; });

/* งานที่ถึงเวลา · กำลังทำอยู่ (≤ 70 นาที) = ไม่ซ้อน · ต้องเข้าสู่ระบบ CMP = ลองใหม่ทุก 3 ชั่วโมง */
async function due() {
  const c = await cfg(), s = await st(); if (!c.key || !c.on || thHour() < c.hour) return null;
  if (s.busyAt && Date.now() - s.busyAt < 70 * 60e3) return null;
  if (s.loginAt && Date.now() - s.loginAt < 3 * 3600e3) return null;
  if (s.quick !== thDate()) return 'auto';
  return null;   /* 1.3.0 (24 พ.ย. 2569): ไม่ดึงหน้ารายงานอัตโนมัติ (CMP ค้างทั้งบัญชี) · ความเคลื่อนไหวรายวันเก็บจากการซิงก์สถานะ */
}
async function tick() { const k = await due(); if (k) await runNow(k); }

async function waitLoad(ms = 60000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(CUR.tab); if (t.status === 'complete') return t; await sleep(500); }
  throw new Error('เปิดหน้า CMP ไม่สำเร็จ (หมดเวลา)');
}
const exec = async (o) => (await chrome.scripting.executeScript(Object.assign({ target: { tabId: CUR.tab }, world: 'MAIN' }, o)))[0];
/* รันฟังก์ชันในหน้าซ้ำจนได้ค่า · each(ค่าระหว่างทาง) */
async function poll(func, ms, every = 1000, each) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const r = await exec({ func }); const v = r && r.result;
    if (v && v.done) return v.res; if (each && v) await each(v);
    await sleep(every);
  }
  return null;
}
async function runNow(kind, manual) {
  const c = await cfg(); if (!c.key) return { state: 'error', msg: 'ยังไม่ได้ใส่คีย์ (กดไอคอนส่วนขยายแล้ววางคีย์จากหน้า HR)' };
  const s0 = await st(); if (s0.busyAt && Date.now() - s0.busyAt < 70 * 60e3 && CUR) return { state: 'busy', msg: 'กำลังซิงก์อยู่ · รอให้เสร็จก่อน' };
  await setSt({ busyAt: Date.now(), prog: { kind, msg: 'กำลังเปิดหน้า CMP…', at: Date.now() } });
  let win = null; CUR = { tab: 0 };
  try {
    win = await chrome.windows.create({ url: CMP + (kind === 'hist' ? '/report' : '/msisdn'), focused: false, state: 'minimized', type: 'normal' });
    CUR.tab = win.tabs[0].id; CUR.win = win.id;
    try { await chrome.tabs.update(CUR.tab, { autoDiscardable: false }); } catch (e) {}
    const t = await waitLoad();
    if (/\/login/.test(t.url || '')) return fin(kind, { state: 'login', msg: 'ต้องเข้าสู่ระบบ CMP' });
    const okTbl = await poll(() => (window.jQuery && jQuery.fn.dataTable && jQuery.fn.dataTable.tables()[0] ? { done: 1, res: 1 } : null), 30000);
    if (!okTbl) { const t2 = await chrome.tabs.get(CUR.tab); return fin(kind, /\/login/.test(t2.url || '') ? { state: 'login', msg: 'ต้องเข้าสู่ระบบ CMP' } : { state: 'error', msg: 'ไม่พบตารางในหน้า CMP' }); }
    await exec({ files: ['sim-bm.js'] });   // รุ่นในส่วนขยาย
    const hrOrigin = new URL(c.hr).origin;
    await exec({ func: u => new Promise(r => { const s = document.createElement('script'); s.src = u; s.onload = () => r(1); s.onerror = () => r(0); (document.head || document.documentElement).appendChild(s); setTimeout(() => r(0), 8000); }), args: [hrOrigin + '/sim-bm.js?t=' + Date.now()] });   // รุ่นล่าสุดจากหน้าเว็บ HR (โหลดไม่ได้ = ใช้รุ่นในส่วนขยาย)
    await exec({ func: (a, k, h, au) => { window.__PMHR_RES = null; window.simBmMain(a, k, h, au); return 1; }, args: [c.api, c.key, c.hr, kind === 'hist' ? 'auto' : kind] });
    const res = await poll(() => (window.__PMHR_RES && window.__PMHR_RES.state !== 'run' ? { done: 1, res: window.__PMHR_RES } : { p: window.__PMHR_PROG || '' }), 60 * 60e3, 3000,
      async v => { if (v.p) await setSt({ busyAt: Date.now(), prog: { kind, msg: v.p, at: Date.now() } }); });
    return fin(kind, res || { state: 'error', msg: 'หมดเวลา (เกิน 60 นาที) · ช่วงที่ส่งแล้วบันทึกไว้ · รอบถัดไปดึงต่อ' });
  } catch (e) { return fin(kind, { state: 'error', msg: TH(String((e && e.message) || e)) }); }
}
async function fin(kind, res) {
  if (CUR && CUR.win) try { await chrome.windows.remove(CUR.win); } catch (e) {}
  CUR = null;
  const p = { busyAt: 0, prog: null, last: { kind, state: res.state, msg: res.msg || '', at: Date.now() } };
  if (res.state === 'done') { p.loginAt = 0; if (kind === 'hist') p.histAt = Date.now(); else p.quick = thDate(); }
  if (res.state === 'login') p.loginAt = Date.now();
  await setSt(p);
  chrome.action.setBadgeText({ text: res.state === 'done' ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#C0392B' });
  if (res.state === 'login') chrome.notifications.create('sim-login', { type: 'basic', iconUrl: 'dtac-logo.png', title: 'SIM Monitor: ต้องเข้าสู่ระบบ CMP', message: 'เข้าสู่ระบบ cmp.dtac.co.th (ติ๊ก "ให้ฉันลงชื่อเข้าใช้เสมอ") แล้วระบบจะซิงก์ต่อเอง', priority: 2 });
  else if (res.state !== 'done') chrome.notifications.create('sim-err', { type: 'basic', iconUrl: 'dtac-logo.png', title: 'SIM Monitor: ซิงก์ไม่สำเร็จ', message: String(res.msg || '').slice(0, 180) });
  return res;
}
chrome.notifications.onClicked.addListener(id => { if (id === 'sim-login') chrome.tabs.create({ url: CMP + '/login' }); });
