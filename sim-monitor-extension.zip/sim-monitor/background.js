/* ส่วนขยาย Chrome "SIM Monitor" (24 พ.ย. 2569 · ผู้ใช้เลือกแบบ ก.) · ซิงก์ CMP → ระบบ HR อัตโนมัติ
 * ไม่เก็บรหัส dtac · ใช้การเข้าสู่ระบบ CMP ของเบราว์เซอร์นี้ (ติ๊ก "ให้ฉันลงชื่อเข้าใช้เสมอ") · CMP มี captcha → หลุดจากระบบ = แจ้งเตือนให้คนเข้าใหม่
 * ทุก 30 นาที (ตั้งแต่ 07:00 เวลาไทย): ยังไม่ซิงก์วันนี้ → เปิดแท็บ /msisdn เบื้องหลัง → simBmMain(..., 'auto') (Sync เต็มเมื่อระบบ HR บอกว่าถึงรอบ)
 *   ประวัติเกิน 7 วัน → เปิดแท็บ /report → ดึงเดือนที่ขาด · เสร็จแล้วปิดแท็บ · โค้ดซิงก์ = sim-bm.js ชุดเดียวกับปุ่มบุ๊กมาร์ก */
importScripts('sim-bm.js');
const CMP = 'https://cmp.dtac.co.th';
const DEF = { api: 'https://pushmedia-hr-api.itsupport2-3a4.workers.dev', hr: 'https://pct.push.co.th/admin.html', key: '', on: true, hour: 7 };
const thDate = () => new Date(Date.now() + 7 * 3600e3).toISOString().slice(0, 10);
const thHour = () => new Date(Date.now() + 7 * 3600e3).getUTCHours();
const cfg = async () => Object.assign({}, DEF, (await chrome.storage.local.get('cfg')).cfg || {});
const st = async () => (await chrome.storage.local.get('st')).st || {};
const setSt = async p => { const s = Object.assign(await st(), p); await chrome.storage.local.set({ st: s }); return s; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

const arm = () => chrome.alarms.create('tick', { periodInMinutes: 30, delayInMinutes: 1 });
chrome.runtime.onInstalled.addListener(arm);
chrome.runtime.onStartup.addListener(() => { arm(); tick(); });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'tick') tick(); });
chrome.runtime.onMessage.addListener((m, s, reply) => { if (m && m.run) { runNow(m.run).then(reply); return true; } });

/* งานที่ถึงเวลา · กำลังทำอยู่ (≤ 40 นาที) = ไม่ซ้อน · ต้องเข้าสู่ระบบ CMP = ลองใหม่ทุก 3 ชั่วโมง */
async function due() {
  const c = await cfg(), s = await st(); if (!c.key || !c.on || thHour() < c.hour) return null;
  if (s.busyAt && Date.now() - s.busyAt < 70 * 60e3) return null;
  if (s.loginAt && Date.now() - s.loginAt < 3 * 3600e3) return null;
  if (s.quick !== thDate()) return 'auto';
  if (!s.histAt || Date.now() - s.histAt > 7 * 864e5) return 'hist';
  return null;
}
async function tick() { const k = await due(); if (k) await runNow(k); }

async function waitLoad(tabId, ms = 60000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') return t; await sleep(500); }
  throw new Error('เปิดหน้า CMP ไม่สำเร็จ (หมดเวลา)');
}
/* รันฟังก์ชันในหน้า (world MAIN) ซ้ำจนได้ค่า */
async function poll(tabId, func, ms, every = 1000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func });
    if (r && r.result) return r.result;
    await sleep(every);
  }
  return null;
}
async function runNow(kind) {
  const c = await cfg(); if (!c.key) return { state: 'error', msg: 'ยังไม่ได้ใส่คีย์ (เปิดหน้าตั้งค่าของส่วนขยาย)' };
  await setSt({ busyAt: Date.now() });
  let tab = null;
  try {
    tab = await chrome.tabs.create({ url: CMP + (kind === 'hist' ? '/report' : '/msisdn'), active: false });
    const t = await waitLoad(tab.id);
    if (/\/login/.test(t.url || '')) return fin(kind, { state: 'login', msg: 'ต้องเข้าสู่ระบบ CMP' }, tab);
    const okTbl = await poll(tab.id, () => !!(window.jQuery && jQuery.fn.dataTable && jQuery.fn.dataTable.tables()[0]), 30000);
    if (!okTbl) { const t2 = await chrome.tabs.get(tab.id); return fin(kind, /\/login/.test(t2.url || '') ? { state: 'login', msg: 'ต้องเข้าสู่ระบบ CMP' } : { state: 'error', msg: 'ไม่พบตารางในหน้า CMP' }, tab); }
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: simBmMain, args: [c.api, c.key, c.hr, kind === 'hist' ? 'auto' : kind] });
    const res = await poll(tab.id, () => (window.__PMHR_RES && window.__PMHR_RES.state !== 'run' ? window.__PMHR_RES : null), 60 * 60e3, 3000);
    return fin(kind, res || { state: 'error', msg: 'หมดเวลา (เกิน 60 นาที) · ช่วงที่ส่งแล้วบันทึกไว้ · รอบถัดไปดึงต่อ' }, tab);
  } catch (e) { return fin(kind, { state: 'error', msg: String((e && e.message) || e) }, tab); }
}
async function fin(kind, res, tab) {
  if (tab) try { await chrome.tabs.remove(tab.id); } catch (e) {}
  const p = { busyAt: 0, last: { kind, state: res.state, msg: res.msg || '', at: Date.now() } };
  if (res.state === 'done') { p.loginAt = 0; if (kind === 'hist') p.histAt = Date.now(); else p.quick = thDate(); }
  if (res.state === 'login') p.loginAt = Date.now();
  await setSt(p);
  chrome.action.setBadgeText({ text: res.state === 'done' ? '' : '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#C0392B' });
  if (res.state === 'login') chrome.notifications.create('sim-login', { type: 'basic', iconUrl: 'dtac-logo.png', title: 'SIM Monitor: ต้องเข้าสู่ระบบ CMP', message: 'เข้าสู่ระบบ cmp.dtac.co.th (ติ๊ก "ให้ฉันลงชื่อเข้าใช้เสมอ") แล้วระบบจะซิงก์ต่อเอง', priority: 2 });
  else if (res.state !== 'done') chrome.notifications.create('sim-err', { type: 'basic', iconUrl: 'dtac-logo.png', title: 'SIM Monitor: ซิงก์ไม่สำเร็จ', message: String(res.msg || '').slice(0, 180) });
  return res;
}
chrome.notifications.onClicked.addListener(id => { if (id === 'sim-login') chrome.tabs.create({ url: CMP + '/login' }); });
